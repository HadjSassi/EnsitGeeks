<?php

    require_once "api.php";
    $api=new Api();
    echo $api->openEvents();
    