<?php
    require_once "api.php";
    $api=new Api();
    print($api->login());